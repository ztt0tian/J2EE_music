CREATE TRIGGER song_play_count_asc
  AFTER INSERT
  ON play_music_history
  FOR EACH ROW
  BEGIN
   UPDATE song SET song.listen_counts=song.listen_counts+1 WHERE song.id=new.song_id;
END;

