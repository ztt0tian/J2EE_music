CREATE PROCEDURE Statis()
  BEGIN
  SELECT * FROM play_music_history;
END;

